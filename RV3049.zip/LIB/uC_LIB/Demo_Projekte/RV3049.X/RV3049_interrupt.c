//##############################################################################
//    filename:        Quick_intr.c
//##############################################################################
//    interrupt functions for uCQuick demo project
//##############################################################################
//
//      Author:            	V.SchK
//      Company:        	HS-Ulm
//
//      Revision:        	2.0 (XC8 compatibility)
//      Date:               November 2014
//     	Assembled using		MPLAB X  1.4 / C18 3.40+ / XC8 1.32+
//
//   	todo	- add comments ;-)
//             	-
//
//##############################################################################

/** I N C L U D E S ***********************************************************/
#include "RV4049pro.h"

/** P R I V A T E  P R O T O T Y P E S ****************************************/
//void high_isr(void);
//void low_isr(void);

/** I N T E R R U P T  V E C T O R S ************* C18 compiler only **********/

#ifndef __XC8        // not XC8 compiler -->> C18 compiler

    #pragma interrupt high_isr
    #define interrupt                           // "remove" xc8 keyword
    #pragma code high_vector=0x08

    #ifdef USE_IR_PRIORITIES
        void interrupt_at_high_vector(void)
        {
          _asm goto high_isr _endasm
        }
        #define low_priority                    // "remove" xc8 keyword
        #pragma interruptlow low_isr
        #pragma code low_vector=0x18
        void interrupt_at_low_vector(void)
        {
          _asm goto low_isr _endasm
        } 
        #pragma code
    #endif
#endif

/** D E C L A R A T I O N S ***************************************************/
//##############################################################################
// Function:        void high_isr(void)
// PreCondition:    None
// Input:
// Output:
// Side Effects:
// Overview:
//##############################################################################
void interrupt high_isr(void)
{
    if (ENC_IR){
        if(ENC_DIR == ENC_DIR_UP) flags.encUp = 1;
          else flags.encDown = 1;
        mENC_IR_RST();
        return;
    }

    if (SEC_IR){
//        if(flags.newSec) -> noch nicht verarbeitet ???
        flags.newSec = 1;
        mSEC_IR_CLR();
        return;
    }
    while(1){;}                         // (detect unexpected IR sources)
}

//##############################################################################
// Function:        void low_isr(void)
// PreCondition:    None
// Input:
// Output:
// Side Effects:
// Overview:
//##############################################################################
#ifdef USE_IR_PRIORITIES
    void interrupt low_priority low_isr(void)
    {
        while(1){;}                         // (detect unexpected IR sources)
    }
#endif
