//##############################################################################
//	filename:		global_def.h    (Projekt BaseComm)
//##############################################################################
//
//  	Author:			VSchK
//  	Company:		HS-Ulm
//
//##############################################################################


//## D E F I N I T I O N S #####################################################

// ---------------------------------------------------------------pin directions
#define INPUT_PIN           1
#define OUTPUT_PIN          0
#define INPUT_REG           0xFF
#define OUTPUT_REG          0x00



//-- module RV3049 -------------------------------------------------------------
#define CS_SPI          LATCbits.LATC2
//#define SCL             LATCbits.LATC3
//#define SDI             LATCbits.LATC4
//#define SDO             LATCbits.LATC5
#define CS_SPI_TRI      TRISCbits.TRISC2
#define SCL_TRI         TRISCbits.TRISC3
#define SDO_TRI         TRISCbits.TRISC5




//#ifdef __DEBUG
//    #define mDEBUG_STOP()    if(mGET_ENC_BTN()){_asm TRAP _endasm}
//#else
//    #define mDEBUG_STOP()
//#endif

//##############################################################################
