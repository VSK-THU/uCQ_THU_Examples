 
//##############################################################################
//    	filename:        	RV3049_main.c
//            
//##############################################################################
//
//      Author:            	VSK
//      Company:        	HS-Ulm
//
//      Revision:        	1.0
//      Date:         		19. Jan. 2016
//     	Assembled using		MPLABX 3.10+ C18 3.40+
//
//      Modifications:
//      tt.mm.jj VSK    - Bla, Bla ...
//
//   	todo	- add comments ;-)
//
//##############################################################################

#include "RV4049pro.h"
#include <timers.h>

union Flags flags;

//##############################################################################
// Function:        void __main(void)
//                      called from the c18 startup code
// PreCondition:    None
// Input:
// Output:
// Side Effects:
// Overview:
//##############################################################################
void main()
{
    while(1){
        if(flags.newSec){
            flags.newSec = 0;
            RTC_readTime();
            LCD_SetCursor(1,0);
            LCD_CharOut(rtcHours.tens + 0x30);
            LCD_CharOut(rtcHours.ones + 0x30);
            LCD_CharOut(':');
            LCD_CharOut(rtcMinutes.tens + 0x30);
            LCD_CharOut(rtcMinutes.ones + 0x30);
            LCD_CharOut(':');
            LCD_CharOut(rtcSeconds.tens + 0x30);
            LCD_CharOut(rtcSeconds.ones + 0x30);
            }
    }//while(1)
}


//##############################################################################
// Function:        void __init(void)
//                      called from the c18 startup code
// PreCondition:    None
// Input:
// Output:
// Side Effects:
// Overview:
//##############################################################################
void __init()
{
    OSCCONbits.IRCF = IRCF_2MHZ;

    OpenTimer1(TIMER_INT_OFF & T5_16BIT_RW & T1_SOURCE_FOSC_4 &
               T1_PS_1_8 & T1_OSC1EN_OFF & T1_SYNC_EXT_OFF,
               TIMER_GATE_OFF);

    CCPTMRS0bits.C2TSEL  = 0;       // timer <-> ccp module (CCP2 / TMR1)
    CCPR2 = 62500;                  // Fosc/4 / prescaler  = 500kHz /8
    CCP2CONbits.CCP2M = 0b1011;     // Compare Mode with Special Event Trigger

// all pins digital IO
    ANSELA = 0x00;
    ANSELB = 0x00;
    ANSELC = 0x00;

    mSET_LED_1_OFF();mSET_LED_2_OFF();mSET_LED_3_OFF();mSET_LED_4_OFF();
    LED_1_TRI = OUTPUT_PIN;
    LED_2_TRI = OUTPUT_PIN;
    LED_3_TRI = OUTPUT_PIN;
    LED_4_TRI = OUTPUT_PIN;


    LCD_Init();
    LCD_ConstTextOut(0,0," RV3049 ");
    LCD_ConstTextOut(1,0,"??:??:??");

    RTC_init();

    flags.all = 0;

    mSEC_IR_EN();
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;         // - globales enable bit
}
