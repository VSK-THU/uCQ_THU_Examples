/* 
 * File:   RV4049.h
 * Author: vschilli
 *
 * Created on 19. Januar 2016, 10:53
 */

#ifndef RV4049PRO_H
#define	RV4049PRO_H

#include <p18cxxx.h>

#include "../../C-LIB/HS-Ulm/uCQuick/uCQ_2013.h"
#include "../../C-LIB/HS-Ulm/LCD/LCD_lib_busy.h"
#include "../../C-LIB/HS-Ulm/RV-304x/RV3049.h"

union Flags{
    char all;

    struct {
        unsigned encUp      : 1;
        unsigned encDown    : 1;
        unsigned bit2       : 1;
        unsigned bit3       : 1;
        unsigned newSec     : 1;
        unsigned bit5 : 1;
        unsigned bit6 : 1;
        unsigned bit7 : 1;
    };
};

extern union Flags flags;

// --------------------------------------------------------------------clock CCP
#define SEC_IR          PIE2bits.CCP2IE && PIR2bits.CCP2IF
#define mSEC_IR_EN()    PIE2bits.CCP2IE = 1
#define mSEC_IR_DIS()   PIE2bits.CCP2IE = 0
#define mSEC_IR_CLR()   PIR2bits.CCP2IF = 0

#endif	/* RV4049PRO_H */

