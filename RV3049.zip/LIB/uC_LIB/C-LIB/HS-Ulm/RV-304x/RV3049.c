//******************************************************************* 
//
//  File:           RV3049.c
//
//                  Real-Time-Clock library
//
//  Author:         VSK
// 
//  Created on      19. Jan 2016
//  Modified        
//
//*******************************************************************

#include "RV3049.h"
#ifdef __XC8                // XC8 compiler
    #include <xc.h>
#else                       // C18 compiler
    #include <p18cxxx.h>
    #include <delays.h>
    #include <spi.h>
#endif


#define CS_SPI_ON()     CS_SPI = 1
#define CS_SPI_OFF()    CS_SPI = 0

//#define SPI_WR_ADDR(a,d)    WriteSPI1(REG_WR | a); WriteSPI1(d) ???
//#define SPI_RD_ADDR(a)      WriteSPI1(REG_RD | a) ?????????????????
//#define SPI_WR_NEXT(d)      WriteSPI1( d )
//#define SPI_RD_NEXT()       ReadSPI1()

typedef enum {
    CTRL_1          = 0x00,
    CTRL_IE,
    CTRL_IF,
    CTRL_STATUS,
    CTRL_RESET,
    SECONDS         = 0x08,
    MINUTES,
    HOURS,
    DATE,
    WEEKDAY,
    MONTH,
    YEAR,
    ALRM_SEC        = 0x10,
    ALRM_MIN,
    ALRM_DAY,
    ALRM_WEEKDAY,
    ALRM_MONTH,
    ALRM_YEAR,
    TMRL            = 0x18,
    TMRH,
    TEMPERATURE_K   = 0x20,
    USER_EEPROM_L   = 0x28,
    USER_EEPROM_H,
    EE_CTRL_1       = 0x30,
    XTAL_DEV,
    XTAL_TCOEF,
    XTAL_T0,
    USER_RAM_0      = 0x38,
    USER_RAM_1,
    USER_RAM_2,
    USER_RAM_3,
    USER_RAM_4,
    USER_RAM_5,
    USER_RAM_6,
    USER_RAM_7
}RV3049_REG_T;
#define REG_WR  0x00
#define REG_RD  0x80


typedef union {
    char    reg;
    struct{
        unsigned WE         : 1;
        unsigned TE         : 1;
        unsigned TAR        : 1;
        unsigned EERE       : 1;
        unsigned SROn       : 1;
        unsigned TD0        : 1;
        unsigned TD1        : 1;
        unsigned CLK_INT    : 1;
    };
}RV3049_CONTROL1_T;

typedef union {
    char    reg;
    struct{
        unsigned bit0   : 1;
        unsigned bit1   : 1;
        unsigned V1F    : 1;
        unsigned V2F    : 1;
        unsigned SR     : 1;
        unsigned PON    : 1;
        unsigned bit6   : 1;
        unsigned EEbusy : 1;
    };
}RV3049_STATUS_T;

typedef union {
    char    reg;
    struct{
        unsigned ThP    : 1;
        unsigned ThE    : 1;
        unsigned FD0    : 1;
        unsigned FD1    : 1;
        unsigned R1k    : 1;
        unsigned R5k    : 1;
        unsigned R20k   : 1;
        unsigned R80k   : 1;
    };
}RV3049_EE_CTRL_1_T;

RV3049_CONTROL1_T   rtcCtrl_1;
RV3049_STATUS_T     rtcStatus;

BCD_T rtcHours, rtcMinutes, rtcSeconds;
// date...


void RTC_init(void)
{
    Delay10KTCYx(100);  // power up ...

    CS_SPI_OFF();
    CS_SPI_TRI = OUTPUT_PIN;
    SCL_TRI = OUTPUT_PIN;
    SDO_TRI = OUTPUT_PIN;    

// max. 1MHz SPI freq
    OpenSPI1(SPI_FOSC_4, MODE_01, SMPMID);
    Delay1KTCYx(1);
    
    CS_SPI_ON();
    WriteSPI(REG_RD | CTRL_STATUS);
    rtcStatus.reg = ReadSPI();
    CS_SPI_OFF();
    
    if(rtcStatus.PON){
//  adjust time
        rtcHours.bcd = 0x12;
        rtcMinutes.bcd = 0x34;
        rtcSeconds.bcd = 0x56;
        RTC_writeTime();
        
        rtcStatus.PON = 0;
        CS_SPI_ON();
        WriteSPI(REG_WR | CTRL_STATUS);
        WriteSPI(rtcStatus.reg);
        CS_SPI_OFF();

        RTC_TChargerOn();
    }

    RTC_readTime();
}


void RTC_TChargerOn()
{
    RV3049_EE_CTRL_1_T  rtcEECtrl_1;

    CS_SPI_ON();                // read Control_1 register
    WriteSPI(REG_RD | CTRL_1);
    rtcCtrl_1.reg = ReadSPI();
    CS_SPI_OFF();

    rtcCtrl_1.EERE = 0;         // Disable automatic EEPROM refresh
    CS_SPI_ON();
    WriteSPI(REG_WR | CTRL_1);
    WriteSPI(rtcCtrl_1.reg);
    CS_SPI_OFF();

    rtcStatus.EEbusy = 1;       // Check if EEPROM is busy?
    while(rtcStatus.EEbusy){
        CS_SPI_ON();
        WriteSPI(REG_RD | CTRL_STATUS);
        rtcStatus.reg = ReadSPI();
        CS_SPI_OFF();
    }

    CS_SPI_ON();
    WriteSPI(REG_RD | CTRL_STATUS);
    rtcEECtrl_1.reg = ReadSPI();
    CS_SPI_OFF();

    rtcEECtrl_1.R1k = 1;        // 1.5kOhm charge resistor

    CS_SPI_ON();
    WriteSPI(REG_WR | EE_CTRL_1);
    WriteSPI(rtcEECtrl_1.reg);
    CS_SPI_OFF();

    rtcStatus.EEbusy = 1;       // Check if EEPROM is busy?
    while(rtcStatus.EEbusy){
        CS_SPI_ON();
        WriteSPI(REG_RD | CTRL_STATUS);
        rtcStatus.reg = ReadSPI();
        CS_SPI_OFF();
    }

    rtcCtrl_1.EERE = 1;         // Enable automatic EEPROM refresh
    CS_SPI_ON();
    WriteSPI(REG_WR | CTRL_1);
    WriteSPI(rtcCtrl_1.reg);
    CS_SPI_OFF();
}

void RTC_readTime(void)
{
    CS_SPI_ON();
    WriteSPI(REG_RD | SECONDS);
    rtcSeconds.bcd = ReadSPI();
    rtcMinutes.bcd = ReadSPI();
    rtcHours.bcd = ReadSPI();
    //...date
    CS_SPI_OFF();
}

void RTC_writeTime(void)
{
    CS_SPI_ON();
    WriteSPI(REG_WR | SECONDS);
    WriteSPI(rtcSeconds.bcd);
    WriteSPI(rtcMinutes.bcd);
    WriteSPI(rtcHours.bcd);
    //...date
    CS_SPI_OFF();
}
