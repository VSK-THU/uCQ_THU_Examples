/* 
 * File:   RV3049.h
 *
 *         Real-Time-Clock library
 *
 * Author: vschilli
 *
 * Created on 19. Januar 2016, 10:57
 */

#ifndef RV3049_H
#define	RV3049_H

#include "global_def.h"

//## Pins define them in "global_def.h" ----------------------------------------
//#define CS_SPI          LATCbits.LATC2    // -> global_def.h
////#define SCL             LATCbits.LATC3
////#define SDI             LATCbits.LATC4
////#define SDO             LATCbits.LATC5
//#define CS_SPI_TRI      TRISCbits.TRISC2
//#define SCL_TRI         TRISCbits.TRISC3
//#define SDI_TRI         TRISCbits.TRISC4
//#define SDO_TRI         TRISCbits.TRISC5


typedef union {
    char bcd;
    struct{
        unsigned ones   : 4;
        unsigned tens   : 4;
    };
}BCD_T;


extern void RTC_init(void);
extern void RTC_TChargerOn(void);
extern void RTC_readTime(void);
extern void RTC_writeTime(void);

extern BCD_T rtcHours, rtcMinutes, rtcSeconds;

#endif	/* RV3049_H */
