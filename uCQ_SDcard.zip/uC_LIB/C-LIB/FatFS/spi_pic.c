/*-----------------------------------------------------------------------------/
/ software SPI control module for PIC18
/------------------------------------------------------------------------------/
/
/  Copyright (C) 2017, VSK / HS-Ulm, all right reserved.
/
/ * This software is a free software and there is NO WARRANTY.
/ * No restriction on use. You can use, modify and redistribute it for
/   personal, non-profit or commercial products UNDER YOUR RESPONSIBILITY.
/ * Redistributions of source code must retain the above copyright notice.
/
/-----------------------------------------------------------------------------*/

#include "device_pic.h"

union spi8bits
{
	char all;
	struct
	{
		unsigned bit0	:1;
		unsigned bit1	:1;
		unsigned bit2	:1;
		unsigned bit3	:1;
		unsigned bit4	:1;
		unsigned bit5	:1;
		unsigned bit6	:1;
		unsigned bit7	:1;
	};
};

union spi8bits spiData;
unsigned char spiDelay;     // value for spi timing loop
unsigned char cntDelay;     // counter for spi timing loop


/*----------------------------------------------------------------------------*/
/* Software SPI initialisation function                                       */
/*----------------------------------------------------------------------------*/
void sdspi_init(void)
{
	sdspi_configSDO();
	sdspi_configSDI();
	sdspi_configSCK();
	sd_configCS();
    spiDelay = SPI_DELAY_VAL;
}

/*----------------------------------------------------------------------------*/
/* Software SPI write function                                                */
/*----------------------------------------------------------------------------*/
signed char sdspi_write(unsigned char txByte)
{
    unsigned char i;

    spiData.all = txByte;
    if(spiDelay == 0){              // SPI fast mode
        SPI_CLK = 0; SPI_DOUT = spiData.bit7; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit6; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit5; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit4; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit3; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit2; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit1; SPI_CLK = 1;
        SPI_CLK = 0; SPI_DOUT = spiData.bit0; SPI_CLK = 1;
        SPI_CLK = 0;
    }
    else{                           // SPI slow mode
        for(i = 8; i > 0; i--){
            SPI_CLK = 0; SPI_DOUT = spiData.bit7;
            SPI_DELAY(); SPI_CLK = 1;
            SPI_DELAY(); SPI_CLK = 0;
            spiData.all = spiData.all << 1;
        }
    }
    SPI_DOUT = 1;

    return 0;
}

/*-----------------------------------------------------------------------*/
/* Software SPI read function                                            */
/*-----------------------------------------------------------------------*/
unsigned char sdspi_read(void)
{
    unsigned char i;

    if(spiDelay == 0){              // SPI fast mode
        SPI_CLK = 1; spiData.bit7 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit6 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit5 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit4 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit3 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit2 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit1 = SPI_DIN; SPI_CLK = 0;
        SPI_CLK = 1; spiData.bit0 = SPI_DIN; SPI_CLK = 0;
    }
    else{                           // SPI slow mode
        for(i = 8; i > 0; i--){
            spiData.all = spiData.all << 1;
            SPI_CLK = 1; SPI_DELAY();
            spiData.bit0 = SPI_DIN;
            SPI_CLK = 0; SPI_DELAY();
        }
    }
    return spiData.all;
}
