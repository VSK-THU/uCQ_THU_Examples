#ifndef DEVICE_PIC_H
#define DEVICE_PIC_H

#include <xc.h>

/*------------------------------------------------------------------------------
 * Define INTOSC for __delay_ms(x)
 *----------------------------------------------------------------------------*/
#define _XTAL_FREQ 64000000 // for delay macros XC8 compiler

extern unsigned char spiDelay, cntDelay;  // in spi_pic.c
#warning "##### Make certain to define SPI-DELAY-VALUE properly !!! #####"
#define SPI_DELAY_VAL 13    // for slow mode (~100kHz @ 64MHz with XC8 free)

// SPI timing macro
#define SPI_DELAY()  for(cntDelay = spiDelay; cntDelay > 0; cntDelay--){;}

#define sdspi_txByte(txByte)	sdspi_write(txByte)
#define sdspi_rxByte()			sdspi_read()
#define	sdspi_setSlowMode()     spiDelay = SPI_DELAY_VAL
#define	sdspi_setFastMode()     spiDelay = 0
void sdspi_init(void);
unsigned char sdspi_read(void);
signed char sdspi_write(  unsigned char txByte );


/* PORT and LATCH configuration for chip select, chip detect and write protect.
   If SD_WP and SD_CD is not defined here then it is not used within the code. */
#define SPI_DOUT    LATCbits.LATC5
#define SPI_DIN     PORTCbits.RC4
#define SPI_CLK     LATCbits.LATC3
#define SD_CS       LATCbits.LATC2
#define sd_select()         SD_CS = 0 // Select the SD chip
#define sd_deselect()       SD_CS = 1 // Deselect the SD chip
//#define SD_CD
//#define SD_WP

/* Any special initialization for SPI related I/O pins is done here
   pins should be configured as listed for input or out put but
   other periphials that are share on the pin may need to be disabled to. */
#define sdspi_configSDO()   LATCbits.LATC5 = 1; TRISCbits.TRISC5 = 0
#define sdspi_configSDI()   ANSELCbits.ANSC4 = 0; TRISCbits.TRISC4 = 1
#warning "##### Make certain there is a pull-up on SDI !!! #####"
#define sdspi_configSCK()   LATCbits.LATC3 = 1; TRISCbits.TRISC3 = 0
#define sd_configCS()       LATCbits.LATC2 = 1; TRISCbits.TRISC2 = 0

#endif  //DEVICE_PIC_H
