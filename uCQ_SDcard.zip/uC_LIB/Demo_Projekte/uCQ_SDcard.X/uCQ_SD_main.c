/*
 * File:   main.c
 * Author: heeg/VSK
 *
 * Created on April 4, 2017, 3:08 PM
 *
 *
 * HS-Ulm demo project FatFS library by Elm Chan
 * http://www.elm-chan.org/fsw/ff/doc/appnote.html
 *
 *
 */


#warning "##### Copy the file header.txt to your SDcard please !!! #####"

//#define USE_LCD
#define USE_DUMMY_DATA  // use this for writing sequential 16bit values to SD

// compare timer (1) is running with FOSC/4; PS_8 -> 2MHz
#define CCPR5_INIT  2000
//    CCPR5 = 40000;              // 2MHz / 40000 = 50Hz -> 20ms
//    CCPR5 = 2000;               // 2MHz / 2000 = 1kHz -> 1ms
//    CCPR5 = 1000;               // 2MHz / 1000 = 2kHz -> 0.5ms
//    CCPR5 = 400;                // 2MHz / 400 = 5kHz -> 0.2ms
//    CCPR5 = 200;                // 2MHz / 200 = 10kHz -> 0.1ms
//    CCPR5 = 100;                // 2MHz / 100 = 20kHz -> 50us


#ifdef __XC8
    #include <xc.h>
//#elif defined(__18CXX)             // C18 compiler
//    #include <p18cxxx.h>
#else
    #error: "########## Compiler not supportet !!! ##########"
#endif

#include "uCQuick/uCQ_2013.h"       // HS-Ulm uCQ demo board
#include "FatFS/ff.h"               // Fat FS
#include "device_pic.h"             // Fat FS
#ifdef USE_LCD
    #include "LCD/LCD_lib_busy.h"       // HS-Ulm character display lib
#endif

// PIC18F26K22 Configuration Bit Settings
// 'C' source line config statements
// CONFIG1H
#pragma config FOSC = INTIO67   // Oscillator Selection bits (Internal oscillator block)
#pragma config PLLCFG = ON      // 4X PLL Enable (Oscillator multiplied by 4)
#pragma config PRICLKEN = ON    // Primary clock enable bit (Primary clock enabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRTEN = ON      // Power-up Timer Enable bit (Power up timer enabled)
#pragma config BOREN = SBORDIS  // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware only (SBOREN is disabled))
#pragma config BORV = 190       // Brown Out Reset Voltage bits (VBOR set to 1.90 V nominal)

// CONFIG2H
#pragma config WDTEN = OFF      // Watchdog Timer Enable bits (Watch dog timer is always disabled. SWDTEN has no effect.)
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC1  // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<5:0> pins are configured as digital I/O on Reset)
#pragma config CCP3MX = PORTB5  // P3A/CCP3 Mux bit (P3A/CCP3 input/output is multiplexed with RB5)
#pragma config HFOFST = ON      // HFINTOSC Fast Start-up (HFINTOSC output and ready status are not delayed by the oscillator stable status)
#pragma config T3CMX = PORTC0   // Timer3 Clock input mux bit (T3CKI is on RC0)
#pragma config P2BMX = PORTB5   // ECCP2 B output mux bit (P2B is on RB5)
#pragma config MCLRE = EXTMCLR  // MCLR Pin Enable bit (MCLR pin enabled, RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection Block 0 (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection Block 1 (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection Block 2 (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection Block 3 (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection Block 0 (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection Block 1 (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection Block 2 (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection Block 3 (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection Block 0 (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection Block 1 (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection Block 2 (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection Block 3 (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0007FFh) not protected from table reads executed in other blocks)


#ifndef USE_LCD
    #define DISPLAY_INIT()      ANSELB &= 0b11000011; TRISB &= 0b11000011
  //there is nothin connected to PORTB so we can go like this
    #define DISPLAY_IDLE()      LATB = 0b11111011;
    #define DISPLAY_FILE_INIT() LATB = 0b11110111;
    #define DISPLAY_MEASURE()   LATB = 0b11101111;
    #define DISPLAY_CLOSE()     LATB = 0b11011111;
    #define DISPLAY_OVFL()      LATB = 0b11001111;
    #define DISPLAY_ERROR()     LATB = 0b11000011;
#else
    #define DISPLAY_INIT()      LCD_Init();                         \
                                LCD_ConstTextOut(0,0,"uCQ-Demo");   \
                                LCD_ConstTextOut(1,0," SDcard ")   
    #define DISPLAY_IDLE()      LCD_ConstTextOut(0,0,"Messung ");   \
                                LCD_ConstTextOut(1,0," Start? ")
    #define DISPLAY_FILE_INIT() LCD_ConstTextOut(1,0," Init...")
    #define DISPLAY_MEASURE()   LCD_ConstTextOut(1,0," Stop?  ")
    #define DISPLAY_CLOSE()     LCD_ConstTextOut(1,0,"Close...")
    #define DISPLAY_OVFL()      LCD_ConstTextOut(0,0,"OVERFLOW");   \
                                LCD_ConstTextOut(1,0," ERROR  ")
    #define DISPLAY_ERROR()     LCD_ConstTextOut(1,0," ERROR! ")
#endif

#ifndef USE_DUMMY_DATA
    #define DATA_IR         PIR1bits.ADIF
    #define mDATA_IR_EN()   PIE1bits.ADIE = 1
    #define mDATA_IR_DIS()  PIE1bits.ADIE = 0
    #define mDATA_IR_CLR()  PIR1bits.ADIF = 0
    #define DATA_LB         ADRESL
    #define DATA_HB         ADRESH
#else
    #define DATA_IR         PIR4bits.CCP5IF
    #define mDATA_IR_EN()   PIE4bits.CCP5IE = 1
    #define mDATA_IR_DIS()  PIE4bits.CCP5IE = 0
    #define mDATA_IR_CLR()  PIR4bits.CCP5IF = 0
    #define DATA_LB         idxBuffer
    #define DATA_HB         idxBuffer
#endif

#define DATA_START()    ctrlFlags.all = 0; idxBuffer = 0;  T1CONbits.TMR1ON = 1
#define DATA_STOP()     T1CONbits.TMR1ON = 0

#define DATA_BUFFER_SIZE    512 // can be much smaller for low data rates!

static void __init(void);
void initFile(void);


union Flags{
    char all;
    struct {
        unsigned nrBuffer   : 1;
        unsigned buf_0_FULL : 1;
        unsigned buf_1_FULL : 1;
        unsigned buf_ovfl   : 1;
        unsigned free       : 4;
    };
};
union Flags ctrlFlags;

FATFS fatFs;
FIL file_rd, file_wr;
BYTE buffer_rd[256];
UINT bytesWritten, bytesRead;
FRESULT fileResult;

unsigned char nrMeasure;
unsigned char dataBuffer_0[DATA_BUFFER_SIZE], dataBuffer_1[DATA_BUFFER_SIZE];
unsigned int idxBuffer;

void main(void)
{
    __init();

    while(1){
        DISPLAY_IDLE();
        while(!mGET_ENC_BTN()){;}
        while(mGET_ENC_BTN()){;}

        DISPLAY_FILE_INIT();
        initFile();
//        f_sync(&file_wr);
        if(fileResult != FR_OK){
            DISPLAY_ERROR();

            __delay_ms(3000);   //while(1){;}
            continue;
        }

        DISPLAY_MEASURE();
        DATA_START();
        while( (!mGET_ENC_BTN()) && (fileResult == FR_OK) ) {
            if(ctrlFlags.buf_ovfl){
                DISPLAY_OVFL();
                fileResult = FR_NOT_READY;
                DATA_STOP();
                __delay_ms(3000);
            }
            else if(ctrlFlags.buf_0_FULL){
                fileResult = f_write(&file_wr, dataBuffer_0, DATA_BUFFER_SIZE, &bytesWritten);
//                f_sync(&file_wr);
                ctrlFlags.buf_0_FULL = 0;
            }
            else if(ctrlFlags.buf_1_FULL){
                fileResult = f_write(&file_wr, dataBuffer_1, DATA_BUFFER_SIZE, &bytesWritten);
//                f_sync(&file_wr);
                ctrlFlags.buf_1_FULL = 0;
            }
        }
        DATA_STOP();
        while(mGET_ENC_BTN()){;}
        DISPLAY_CLOSE();
        f_close(&file_wr);
        f_mount(0, "", 0);
        __delay_ms(1000);
    }
}


void initFile(void)
{
    unsigned char filename[] = "MESS_000.dat";

    fileResult = f_mount(&fatFs, "", 1);
    if(fileResult != FR_OK) return;

    //create a new destination file
    while(fileResult == FR_OK){
        fileResult = f_open(&file_wr, filename, FA_OPEN_EXISTING);
        if(fileResult == FR_OK){
            f_close(&file_wr);
            if(++filename[7] > '9'){
                filename[7] = '0';
                if(++filename[6] > '9'){
                    filename[6] = '0';
                    if(++filename[5] > '9'){
                        filename[5] = '0';
                    }
                }
            }
        }
    }
    if(fileResult == FR_NO_FILE){
        fileResult = f_open(&file_wr, filename, FA_WRITE | FA_OPEN_ALWAYS);
    }
    if (fileResult != FR_OK) return;
    filename[8] = 0; 
#ifdef USE_LCD
    LCD_TextOut(0, 0, filename);
#endif
    //copy a header to new file
    fileResult = f_open(&file_rd, "header.txt", FA_READ);
    if (fileResult != FR_OK){ fileResult = FR_OK; return; }

    fileResult = f_read(&file_rd, buffer_rd, sizeof buffer_rd, &bytesRead);
    f_close(&file_rd);
    if (fileResult != FR_OK){  fileResult = FR_OK; return; }

    if (!( fileResult || bytesRead == 0 )) {
        fileResult = f_write(&file_wr, buffer_rd, bytesRead, &bytesWritten);
    }
    f_sync(&file_wr);
    return;
}


/*------------------------------------------------------------------------------
 * Initialisieren der Hardware
 *----------------------------------------------------------------------------*/
static void __init(void)
{
    /* initialising of oszillator */
	OSCCONbits.IRCF = IRCF_16MHZ;   // 16MHz *4(PLL) -> 64MHz
	OSCTUNEbits.PLLEN = 1;

#ifndef USE_DUMMY_DATA
    POTI_TRI = INPUT_PIN;
    POTI_ANS = ANALOG_IN;
    ADCON1bits.NVCFG = 0;       // Vref- = AVss
    ADCON1bits.PVCFG = 0;       // Vref+ = AVdd
    ADCON1bits.TRIGSEL = 0;     // special event trigger from CCP5
    ADCON2bits.ACQT = 0b010;    // 2*2 (4) TAD
    ADCON2bits.ADCS = 0b110;    // Conversion clock = Fosc/64
    ADCON2bits.ADFM = 1;        // right justified
    ADCON0bits.CHS = 0;         // ADC channel 0
    ADCON0bits.ADON = 1;
#endif

// use TMR1 and CCP5 for adc special event trigger (data sampling)
    T1GCONbits.TMR1GE = 0;      // Timer1/ counts regardless of gate function
    T1CONbits.TMR1CS = 0b00;    // Timer1 clock source is instruction clock (FOSC/4)
    T1CONbits.T1CKPS = 3;       // 2^3 -> 8 Prescale value -> TMR1clk = 2MHz
//    T1CONbits.TMR1ON = 1;       // switch on Timer1
    CCP5CONbits.CCP5M = 0b1011; // Compare Mode with Special Event Trigger
    CCPTMRS1bits.C5TSEL = 0b00; // timer <-> ccp module (CCP5 / TMR1)
//    CCPR5 = 40000;              // 2MHz / 40000 = 50Hz -> 20ms
//    CCPR5 = 2000;               // 2MHz / 2000 = 1kHz -> 1ms
//    CCPR5 = 400;                // 2MHz / 400 = 5kHz -> 0.2ms
//    CCPR5 = 200;                // 2MHz / 200 = 10kHz -> 0.1ms
//    CCPR5 = 100;                // 2MHz / 100 = 20kHz -> 50us
    CCPR5 = CCPR5_INIT;

    ENC_BTN_ANS = DIGITAL_IN; ENC_BTN_TRI = INPUT_PIN;

    DISPLAY_INIT();
    __delay_ms(3000);

    ctrlFlags.all = 0;
    nrMeasure = 0;

    mDATA_IR_EN();
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;
}

/*------------------------------------------------------------------------------
 * Interrupt service routine
 *----------------------------------------------------------------------------*/
void high_priority interrupt ISR(void)
{
    static unsigned int cntLoop = 0;

    if(DATA_IR){
//        LATBbits.LATB2 ^= 1;
        mDATA_IR_CLR();

        if(ctrlFlags.nrBuffer){
            dataBuffer_1[idxBuffer++] = DATA_LB;
            dataBuffer_1[idxBuffer++] = DATA_HB;
        }
        else{
            dataBuffer_0[idxBuffer++] = DATA_LB;
            dataBuffer_0[idxBuffer++] = DATA_HB;
        }

        if(idxBuffer == DATA_BUFFER_SIZE){
            if(ctrlFlags.nrBuffer == 0){ 
                ctrlFlags.buf_0_FULL = 1;
                if(ctrlFlags.buf_1_FULL)
                    ctrlFlags.buf_ovfl = 1;
            }
            else{
                ctrlFlags.buf_1_FULL = 1;
                if(ctrlFlags.buf_0_FULL)
                    ctrlFlags.buf_ovfl = 1;
            }
            ctrlFlags.nrBuffer ^= 1;
            idxBuffer = 0;
            if(ctrlFlags.nrBuffer == 0){
                cntLoop++;
            }
        }
    }
    else while(1);  // catch unextected interrupts...
}
